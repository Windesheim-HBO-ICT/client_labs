var myApp = {
	init: function(){return true;}
}